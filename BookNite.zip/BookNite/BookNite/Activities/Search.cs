﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using BookNite.Resources.layout;

namespace BookNite.Resources.Layout
{
    [Activity(Label = "Search")]
    public class Search : Activity
    {
        EditText txtSeach;
        Button btnSeach;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            txtSeach = FindViewById<EditText>(Resource.Id.txtSearch);
            btnSeach = FindViewById<Button>(Resource.Id.btnSearch);

            btnSeach.Click += BtnSeach_Click;
        }

        private void BtnSeach_Click(object sender, EventArgs e)
        {
            StartActivity(typeof(Books));
        }
    }
}