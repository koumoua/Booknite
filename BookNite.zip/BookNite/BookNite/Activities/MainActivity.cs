﻿using Android.App;
using Android.Widget;
using Android.OS;

namespace BookNite.Resources.layout
{
    [Activity(Label = "BookNite", MainLauncher = true)]
    public class MainActivity : Activity
    {
        EditText txtEmail;
        EditText txtPassword;
        Button btnLogin;
        Button btnRegister;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            txtEmail = FindViewById<EditText>(Resource.Id.txtEmail);
            txtPassword = FindViewById<EditText>(Resource.Id.txtPassword);
            btnLogin = FindViewById<Button>(Resource.Id.btnLogin);
            btnRegister = FindViewById<Button>(Resource.Id.btnRegister);

            btnRegister.Click += BtnRegister_Click;
            btnLogin.Click += BtnLogin_Click;
        }

        private void BtnLogin_Click(object sender, System.EventArgs e)
        {
            
        }

        private void BtnRegister_Click(object sender, System.EventArgs e)
        {
            StartActivity(typeof(Register));
        }
    }
}

