﻿using Android.App;
using Android.Widget;
using Android.OS;

namespace BookNite3
{
    [Activity(Label = "BookNite3", MainLauncher = true)]
    public class MainActivity : Activity
    {
        EditText txtEmail;
        EditText txtPassword;
        Button btnLogin;
        Button btnCreate;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);        

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);


            txtEmail = FindViewById<EditText>(Resource.Id.txtEmail);
            txtPassword = FindViewById<EditText>(Resource.Id.txtPassword);
            btnLogin = FindViewById<Button>(Resource.Id.btnLogin);
            btnCreate = FindViewById<Button>(Resource.Id.btnCreate);


            btnLogin.Click += BtnLogin_Click;
            btnCreate.Click += BtnCreate_Click;

        }

        private void BtnCreate_Click(object sender, System.EventArgs e)
        {
            StartActivity(typeof(//register page))
        }

        private void BtnLogin_Click(object sender, System.EventArgs e)
        {
            StartActivity(typeof(BookList));
        }
    }
}

